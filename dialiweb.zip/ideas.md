# Direction de conception — Site officiel Diali AI

## Source de vérité

L’image `Le-design_qu'il_faut_reproduire_adapter_pour_le_site_de_Diali_AI.jfif` fournie dans les sources est la référence visuelle explicite et confirmée par l’utilisateur. Adapter sa composition de site d’entreprise technologique au contenu Diali AI : navigation compacte en haut, hero spectaculaire et lisible, scène visuelle centrée sur un écran/ordinateur portable affichant un produit crédible, boutons bleus, rangée de cartes de services/preuves, puis sections aérées et structurées. La fidélité porte sur la hiérarchie, le rythme, la composition et le caractère professionnel de la référence, pas sur ses textes génériques ni son logo.

Ne pas reprendre l’ancien thème sombre or/vert du HTML de départ. Garder cependant le logo officiel Diali AI existant sans le redessiner.

## Mouvement et principes

Site institutionnel B2B contemporain, inspiré du design éditorial des sites de technologie professionnelle. Priorité à la confiance, à la clarté, à la preuve terrain et à la lisibilité mobile. Rythme en sections contrastées : hero bleu nuit, surfaces principales blanc et gris bleuté, blocs secondaires bleu pâle, accents bleus nets. Une photographie ou une interface authentique doit expliquer l’usage, jamais servir de décor sans rapport.

## Palette

- Bleu nuit : `#0B1735`, pour l’en-tête, le hero et les zones de marque.
- Bleu principal : `#2376F5`, pour les actions, liens et éléments actifs.
- Cyan clair : `#56D8F5`, utilisé avec retenue dans les détails d’interface.
- Fond : `#F5F8FC` ; surfaces : `#FFFFFF`.
- Texte : `#15223B` ; texte secondaire : `#64748B`.
- Vert uniquement comme code fonctionnel de validation/paiement et dans le logo existant.

## Mise en page et signatures

- Conteneur desktop large, marges généreuses, grille régulière ; empilement propre sur mobile.
- Barre de navigation compacte, logo Diali, ancres utiles, sélecteur FR/EN et CTA d’e-mail.
- Hero centré fidèle à la référence : promesse et CTA au-dessus d’un visuel large d’ordinateur portable, puis rangée de quatre cartes de preuves/métriques.
- Cartes blanches avec bordure discrète, rayon modéré, ombre légère ; métriques courtes sous le hero, puis blocs de contenu hiérarchisés.
- Présenter une simulation UI construite en HTML/CSS à partir des étapes vérifiées, pas une fausse capture d’une intégration en production.
- Employer les portraits réels livrés dans les ressources pour l’équipe et les preuves visuelles pertinentes du projet ; ne jamais générer ou substituer les visages des personnes nommées.
- Utiliser des icônes Font Awesome cohérentes et monochromes. Aucun emoji.

## Typographie et voix

Titres modernes sans sérif, gras et serrés, inspirés de Manrope ou d’une alternative système de bonne qualité ; corps Inter/Arial, taille et interlignage confortables. Ton précis, confiant, concret et compréhensible par investisseurs, partenaires et commerçants. Français relu, accents et ponctuation soignés ; anglais naturel.

## Interactions et mouvement

Sélecteur FR/EN sans rechargement, navigation mobile accessible, boutons d’ancrage, curseur du calculateur financier et démonstration de parcours pilotable. Transitions courtes, sans animation distrayante ; respecter `prefers-reduced-motion`. Contrastes lisibles, états clavier visibles, textes alternatifs sur les photos.

## Marque et visuels

Réutiliser le logo officiel présent dans les fichiers Diali AI, les portraits de Loutaladio Danick Arcel, Christian Kissita Safoula et Picka Kelly, ainsi que les supports authentiques du dossier. Éviter les visuels web sous licence incertaine, les images filigranées, les statistiques intégrées à une infographie dont la source n’est pas vérifiée et toute attribution inventée. Le visuel du parcours peut être assemblé avec du HTML/CSS et des icônes Font Awesome, afin de conserver des textes précis et un rendu adapté à la référence.

Le hero intègrera une illustration photographique d’une nature morte professionnelle (ordinateur, téléphone et colis), sans personne, marque ni texte ; elle évoquera l’expérience cible et ne sera pas présentée comme une preuve terrain. Le parcours de produit et ses textes seront construits en HTML/CSS pour rester exacts et bilingues.

## Contraintes de contenu

- Conserver les faits validés du dossier de candidature ; distinguer clairement hypothèses, objectifs, prévisions et réalisations du pilote.
- Pour le modèle économique, afficher les paramètres utilisés et la formule du GMV ; ne pas présenter la projection comme une performance déjà réalisée.
- Ne pas afficher de numéro WhatsApp qui n’est pas validé ; orienter les appels à l’action vers l’adresse e-mail fournie et les sections de démonstration.
- Le dossier fourni nomme Picka Kelly comme collaborateur, sans préciser de titre ; afficher son nom avec un intitulé neutre « Collaborateur ».
- Le site est une page publique légère sans compte, base de données ni backend. Préserver le contenu dans le HTML initial pour les moteurs de recherche.
- Hero centré fidèle à la référence : promesse et CTA au-dessus d’un visuel large d’ordinateur portable, puis rangée de quatre cartes de preuves/métriques.
